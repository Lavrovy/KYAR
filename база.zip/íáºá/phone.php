<?php

if(isset($_POST['password']) && isset($_POST['name'])){
 echo $_POST['password'].'<br>';
 echo $_POST['name'];
}