 // Получаем текущий список товаров из LocalStorage или устанавливаем его по умолчанию в пустой массив
 let cart = JSON.parse(localStorage.getItem('cart')) || [];

 // Отображаем текущий список товаров в корзине
 function renderCart() {
     let cartList = document.getElementById('cartList');
     cartList.innerHTML = '';
     let totalPrice = 0;

     cart.forEach(item => {
         let li = document.createElement('li');
         li.textContent = `${item.name} - ${item.price} руб.`;
         let removeButton = document.createElement('button');
         removeButton.textContent = '✖';
         removeButton.addEventListener('click', () => {
             removeFromCart(item);
         });
         li.appendChild(removeButton);
         cartList.appendChild(li);
         totalPrice += item.price;
     });

     let totalPriceLi = document.createElement('li');
     totalPriceLi.textContent = `Итоговая стоимость: ${totalPrice} руб.`;
     cartList.appendChild(totalPriceLi);
 }

 // Добавляем товар в корзину и сохраняем данные в LocalStorage
 function addToCart(name, price) {
     let existingItem = cart.find(item => item.name === name);

     if (existingItem) {
         existingItem.price += parseInt(price);
     } else {
         cart.push({ name, price: parseInt(price) });
     }

     localStorage.setItem('cart', JSON.stringify(cart));
     renderCart();
 }

 // Удаляем товар из корзины и сохраняем данные в LocalStorage
 function removeFromCart(item) {
     cart = cart.filter(i => i.name !== item.name);
     localStorage.setItem('cart', JSON.stringify(cart));
     renderCart();
 }

 // Навешиваем обработчик нажатия на кнопки "В корзину"
 let addToCartButtons = document.querySelectorAll('.addToCart');
 addToCartButtons.forEach(button => {
     button.addEventListener('click', () => {
         let name = button.dataset.name;
         let price = button.dataset.price;
         addToCart(name, price);
     });
 });
 

 // Отображаем текущий список товаров в корзине при загрузке страницы
 renderCart();


 