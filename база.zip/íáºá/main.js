// Прослушиваем клик по ссылке с якорем
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault(); // Отменяем стандартное поведение

        // Получаем целевой элемент, к которому нужно прокрутить страницу
        const targetId = this.getAttribute('href');
        const targetElement = document.querySelector(targetId);

        // Плавная прокрутка к элементу
        targetElement.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    });
});

function showPopup() {
  document.getElementById("popup").style.display = "block";
  document.body.style.position = 'fixed';
  
}

function hidePopup() {
  document.getElementById("popup").style.display = "none";
  document.body.style.position = '';
  document.body.style.top = '';
  document.body.style.width = '';
  window.scrollTo(0, scrollTop);
}
function showPopup1() {
  document.getElementById("popup1").style.display = "block";
  document.body.style.position = 'fixed';
}

function hidePopup1() {
  document.getElementById("popup1").style.display = "none";
  document.body.style.position = '';
  document.body.style.top = '';
  document.body.style.width = '';
  window.scrollTo(0, scrollTop);
}
function showPopup2() {
  document.getElementById("popup2").style.display = "block";
  document.body.style.position = 'fixed';
}

function hidePopup2() {
  document.getElementById("popup2").style.display = "none";
  document.body.style.position = '';
  document.body.style.top = '';
  document.body.style.width = '';
  window.scrollTo(0, scrollTop);
}
let slideIndex = 0;
const slides = document.querySelectorAll('.slide');
const totalSlides = slides.length;

document.querySelector('.prev').addEventListener('click', function() {
  moveSlide(-1);
});

document.querySelector('.next').addEventListener('click', function() {
  moveSlide(1);
});

function moveSlide(step) {
  slideIndex = (slideIndex + step + totalSlides) % totalSlides;
  const offset = -slideIndex * 100;
  document.querySelector('.slides').style.transform = `translateX(${offset}%)`;
}
// Пример скрипта для увеличения счетчика на 1
var badge = document.querySelector('.badge');
var count = 0;

// При каждом клике на кнопку "добавить в корзину"
document.querySelector("#mal").addEventListener('click', function() {
    count++;
    badge.innerText = count;
});

function moveSlide(step) {
  slideIndex = (slideIndex + step + totalSlides) % totalSlides;
  const offset = -slideIndex * 100;
  document.querySelector('.slides').style.transform = `translateX(${offset}%)`;
}
// Пример скрипта для увеличения счетчика на 1
var badge = document.querySelector('.badge');
var count = 0;

// При каждом клике на кнопку "добавить в корзину"
document.querySelector("#mal1").addEventListener('click', function() {
    count++;
    badge.innerText = count;
});

function moveSlide(step) {
  slideIndex = (slideIndex + step + totalSlides) % totalSlides;
  const offset = -slideIndex * 100;
  document.querySelector('.slides').style.transform = `translateX(${offset}%)`;
}
// Пример скрипта для увеличения счетчика на 1
var badge = document.querySelector('.badge');
var count = 0;

// При каждом клике на кнопку "добавить в корзину"
document.querySelector("#mal2").addEventListener('click', function() {
    count++;
    badge.innerText = count;
});

function moveSlide(step) {
  slideIndex = (slideIndex + step + totalSlides) % totalSlides;
  const offset = -slideIndex * 100;
  document.querySelector('.slides').style.transform = `translateX(${offset}%)`;
}
// Пример скрипта для увеличения счетчика на 1
var badge = document.querySelector('.badge');
var count = 0;

// При каждом клике на кнопку "добавить в корзину"
document.querySelector("#sred").addEventListener('click', function() {
    count++;
    badge.innerText = count;
});
function moveSlide(step) {
  slideIndex = (slideIndex + step + totalSlides) % totalSlides;
  const offset = -slideIndex * 100;
  document.querySelector('.slides').style.transform = `translateX(${offset}%)`;
}
// Пример скрипта для увеличения счетчика на 1
var badge = document.querySelector('.badge');
var count = 0;

// При каждом клике на кнопку "добавить в корзину"
document.querySelector("#sred1").addEventListener('click', function() {
    count++;
    badge.innerText = count;
});
function moveSlide(step) {
  slideIndex = (slideIndex + step + totalSlides) % totalSlides;
  const offset = -slideIndex * 100;
  document.querySelector('.slides').style.transform = `translateX(${offset}%)`;
}
// Пример скрипта для увеличения счетчика на 1
var badge = document.querySelector('.badge');
var count = 0;

// При каждом клике на кнопку "добавить в корзину"
document.querySelector("#sred2").addEventListener('click', function() {
    count++;
    badge.innerText = count;
});
function moveSlide(step) {
  slideIndex = (slideIndex + step + totalSlides) % totalSlides;
  const offset = -slideIndex * 100;
  document.querySelector('.slides').style.transform = `translateX(${offset}%)`;
}
// Пример скрипта для увеличения счетчика на 1
var badge = document.querySelector('.badge');
var count = 0;

// При каждом клике на кнопку "добавить в корзину"
document.querySelector("#bol").addEventListener('click', function() {
    count++;
    badge.innerText = count;
});
function moveSlide(step) {
  slideIndex = (slideIndex + step + totalSlides) % totalSlides;
  const offset = -slideIndex * 100;
  document.querySelector('.slides').style.transform = `translateX(${offset}%)`;
}
// Пример скрипта для увеличения счетчика на 1
var badge = document.querySelector('.badge');
var count = 0;

// При каждом клике на кнопку "добавить в корзину"
document.querySelector("#bol1").addEventListener('click', function() {
    count++;
    badge.innerText = count;
});
function moveSlide(step) {
  slideIndex = (slideIndex + step + totalSlides) % totalSlides;
  const offset = -slideIndex * 100;
  document.querySelector('.slides').style.transform = `translateX(${offset}%)`;
}
// Пример скрипта для увеличения счетчика на 1
var badge = document.querySelector('.badge');
var count = 0;

// При каждом клике на кнопку "добавить в корзину"
document.querySelector("#bol2").addEventListener('click', function() {
    count++;
    badge.innerText = count;
});













